import tkinter as tk
from tkinter import messagebox
import matplotlib.pyplot as plt


# Function to calculate BMI
def calculate_bmi(weight, height):
    """
    Calculate the BMI given weight in kg and height in meters.
    """
    return weight / (height ** 2)


# Function to categorize BMI
def categorize_bmi(bmi):

    if bmi < 18.5:
        return "Underweight"
    elif 18.5 <= bmi < 24.9:
        return "Normal weight"
    elif 25 <= bmi < 29.9:
        return "Overweight"
    else:
        return "Obesity"


# Function to calculate and display BMI
def calculate_and_display_bmi():

    try:
        weight = float(weight_entry.get())
        height = float(height_entry.get())

        if weight <= 0 or height <= 0:
            raise ValueError("Weight and height must be positive values.")

        bmi = calculate_bmi(weight, height)
        category = categorize_bmi(bmi)

        result_label.config(text=f"Your BMI is: {bmi:.2f}\nCategory: {category}")

        # Store historical data (weight, height, bmi)
        historical_data.append((weight, height, bmi))

    except ValueError:
        messagebox.showerror("Input Error",
                             "Invalid input. Please enter positive numerical values for weight and height.")


# Function to visualize BMI trends
def visualize_bmi_trends():
    """
    Visualize historical BMI data trends using a line chart.
    """
    if historical_data:
        bmis = [data[2] for data in historical_data]
        plt.plot(bmis)
        plt.title("BMI Trend")
        plt.xlabel("Entry Number")
        plt.ylabel("BMI")
        plt.show()
    else:
        messagebox.showinfo("No Data", "No historical data available for visualization.")


# Main application
def main():
    """
    Create the main application GUI and start the event loop.
    """
    root = tk.Tk()
    root.title("BMI Calculator")

    # Create input fields and labels
    tk.Label(root, text="Enter your weight (kg):").grid(row=0, column=0)
    global weight_entry
    weight_entry = tk.Entry(root)
    weight_entry.grid(row=0, column=1)

    tk.Label(root, text="Enter your height (m):").grid(row=1, column=0)
    global height_entry
    height_entry = tk.Entry(root)
    height_entry.grid(row=1, column=1)

    # Create buttons for calculating BMI and visualizing trends
    calculate_button = tk.Button(root, text="Calculate BMI", command=calculate_and_display_bmi)
    calculate_button.grid(row=2, column=0, columnspan=2)

    visualize_button = tk.Button(root, text="Visualize BMI Trends", command=visualize_bmi_trends)
    visualize_button.grid(row=3, column=0, columnspan=2)

    # Create a label to display the result
    global result_label
    result_label = tk.Label(root, text="")
    result_label.grid(row=4, column=0, columnspan=2)

    # Initialize historical data storage
    global historical_data
    historical_data = []

    # Start the main event loop
    root.mainloop()


if __name__ == "__main__":
    main()
