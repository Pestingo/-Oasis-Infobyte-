import tkinter as tk
from tkinter import messagebox
import random
import string
import pyperclip


# Function to generate password
def generate_password(length, use_letters, use_numbers, use_symbols):
    """
    Generate a random password based on user-defined criteria.
    """
    char_set = ''
    if use_letters:
        char_set += string.ascii_letters  # Upper and lower case letters
    if use_numbers:
        char_set += string.digits  # Numeric digits
    if use_symbols:
        char_set += string.punctuation  # Punctuation symbols

    if not char_set:
        raise ValueError("At least one character set must be included.")

    # Generate a random password
    password = ''.join(random.choice(char_set) for _ in range(length))
    return password


# Function to handle password generation and display the result
def generate_and_display_password():
    """
    Generate and display the password based on user-defined options.
    """
    try:
        length = int(length_entry.get())
        if length <= 0:
            raise ValueError("Password length must be positive.")

        # Retrieve user preferences for character types
        use_letters = letters_var.get()
        use_numbers = numbers_var.get()
        use_symbols = symbols_var.get()

        # Generate password
        password = generate_password(length, use_letters, use_numbers, use_symbols)

        # Display the password
        password_entry.delete(0, tk.END)
        password_entry.insert(0, password)

    except ValueError as e:
        messagebox.showerror("Input Error", str(e))


# Function to copy password to clipboard
def copy_to_clipboard():
    """
    Copy the generated password to the clipboard.
    """
    password = password_entry.get()
    if password:
        pyperclip.copy(password)
        messagebox.showinfo("Copied", "Password copied to clipboard.")


# Main function to create and run the GUI
def main():
    # the main application window
    root = tk.Tk()
    root.title("Password Generator")

    # input for password length
    tk.Label(root, text="Password Length:").grid(row=0, column=0)
    global length_entry
    length_entry = tk.Entry(root)
    length_entry.grid(row=0, column=1)

    # checkboxes for character types
    global letters_var, numbers_var, symbols_var
    letters_var = tk.BooleanVar(value=True)
    numbers_var = tk.BooleanVar(value=True)
    symbols_var = tk.BooleanVar(value=True)

    tk.Checkbutton(root, text="Include Letters", variable=letters_var).grid(row=1, column=0, sticky="W")
    tk.Checkbutton(root, text="Include Numbers", variable=numbers_var).grid(row=1, column=1, sticky="W")
    tk.Checkbutton(root, text="Include Symbols", variable=symbols_var).grid(row=1, column=2, sticky="W")

    # buttons for generating password and copying to clipboard
    generate_button = tk.Button(root, text="Generate Password", command=generate_and_display_password)
    generate_button.grid(row=2, column=0, columnspan=2, pady=10)

    copy_button = tk.Button(root, text="Copy to Clipboard", command=copy_to_clipboard)
    copy_button.grid(row=2, column=2, pady=10)

    # Entry field to display generated password
    global password_entry
    password_entry = tk.Entry(root, width=30)
    password_entry.grid(row=3, column=0, columnspan=3)

    # Start the main event loop
    root.mainloop()


if __name__ == "__main__":
    main()
