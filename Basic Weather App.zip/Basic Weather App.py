import tkinter as tk
import requests


def fetch_weather(location):
    """
    Fetch current weather data for the specified location from an API.
    """
    api_key = 'YOUR_API_KEY' "I don't have free one currently"
    url = f'http://api.openweathermap.org/data/2.5/weather?q={location},za&appid={api_key}&units=metric'

    response = requests.get(url)
    data = response.json()

    return data


def display_weather(location):
    """
    weather information in the GUI.
    """
    data = fetch_weather(location)

    if data['cod'] == 200:
        weather_info = data['weather'][0]
        main_info = data['main']

        weather_description_label.config(text=f"Description: {weather_info['description']}")
        temperature_label.config(text=f"Temperature: {main_info['temp']}°C")
        humidity_label.config(text=f"Humidity: {main_info['humidity']}%")
    else:
        weather_description_label.config(text="Failed to fetch weather data.")
        temperature_label.config(text="")
        humidity_label.config(text="")


def on_submit():
    """
    Event handler for the submit button.
    """
    location = location_entry.get()
    display_weather(location)


# the main application window
root = tk.Tk()
root.title("South Africa Weather App")

# input field for location
location_label = tk.Label(root, text="Enter city name in South Africa:")
location_label.grid(row=0, column=0)
location_entry = tk.Entry(root)
location_entry.grid(row=0, column=1)

# submit button
submit_button = tk.Button(root, text="Submit", command=on_submit)
submit_button.grid(row=0, column=2)

# labels to display weather information
weather_description_label = tk.Label(root, text="")
weather_description_label.grid(row=1, column=0, columnspan=3)

temperature_label = tk.Label(root, text="")
temperature_label.grid(row=2, column=0, columnspan=3)

humidity_label = tk.Label(root, text="")
humidity_label.grid(row=3, column=0, columnspan=3)

# the main event loop
root.mainloop()
