import socket
import threading


def handle_client(client_socket, client_address):
    print(f"Accepted connection from {client_address}")

    while True:
        try:
            message = client_socket.recv(1024).decode()
            if not message:
                break
            print(f"Received message from {client_address}: {message}")

            # Broadcast message to all connected clients
            for client in clients:
                if client != client_socket:
                    client.send(message.encode())
        except Exception as e:
            print(f"Error handling client {client_address}: {e}")
            break

    print(f"Connection from {client_address} closed")
    client_socket.close()
    clients.remove(client_socket)


def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('0.0.0.0', 5555))
    server_socket.listen(5)

    print("Server listening on port 5555")

    while True:
        client_socket, client_address = server_socket.accept()
        clients.append(client_socket)
        client_thread = threading.Thread(target=handle_client, args=(client_socket, client_address))
        client_thread.start()


def start_client():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('localhost', 5555))

    while True:
        try:
            message = input()
            client_socket.send(message.encode())
        except Exception as e:
            print("Error sending message:", e)
            break


clients = []

if __name__ == "__main__":
    server_thread = threading.Thread(target=start_server)
    server_thread.start()

    start_client()
